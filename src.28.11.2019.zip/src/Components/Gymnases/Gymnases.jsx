import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';

export default function Gymnases() {
  return (
    <Fragment>
      <h3>Gymnases de la poule B</h3>
      <Typography>
        Bientôt ici, la liste des gymnases avec des liens
        vers google maps.
      </Typography>
    </Fragment>
  )
}