import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
// import blueGrey from '@material-ui/core/colors/blueGrey';
import Grid from '@material-ui/core/Grid';
import Container from '@material-ui/core/Container';
import { Typography } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  avatarOui: {
    backgroundColor: "#8ad5fb", //"#8fd0ff",
    color: "black",
    width: 30,
    height: 30,
  },
  avatarNonRepondu: {
    backgroundColor: "#E9F1F7", //blueGrey[50],
    color: "black",
    width: 30,
    height: 30,
  },
  avatarSiBesoin: {
    backgroundColor: "#f5b829",//"#ffd746",
    color: "black",
    width: 30,
    height: 30,
  },
  avatarAbsent: {
    backgroundColor: "#bcd4de", //blueGrey[200],
    color: "black",
    width: 30,
    height: 30,
  },
  margins: {
    marginRight: theme.spacing(2),
  },
}));

export default function AffichageTotaux(props) {
  const classes = useStyles();
  const { totaux } = props;

  //On complète les totaux pour éviter les erreurs
  if (totaux) {
    const possibilites = ['Présent(e)', 'Oui', 'Si besoin', 'Provisoire', 'Non renseigné', 'Non', 'Absent(e)']
    for (const poss of possibilites) {
      if (!totaux[poss]) {
        totaux[poss] = 0
      }
    }
  }

  const Presents = (
    <Avatar className={classes.avatarOui} >
      <Typography>
        {totaux['Oui'] + totaux['Présent(e)']}
      </Typography>
    </ Avatar>
  )
  const Provisoire = (
    <Avatar className={classes.avatarSiBesoin} >
      <Typography>
        {totaux['Provisoire'] + totaux['Si besoin']}
      </Typography>
    </ Avatar>
  )
  const NonRepondu = (
    <Avatar className={classes.avatarNonRepondu} >
      <Typography>
        {totaux['Non renseigné']}
      </Typography>
    </ Avatar>
  )
  const Absents = (
    <Avatar className={classes.avatarAbsent} >
      <Typography>
        {totaux['Non'] + totaux['Absent(e)']}
      </Typography>
    </ Avatar>
  )

  return (
    <Container maxWidth="xs" >
      <Grid
        container
        direction="row"
        justify="flex-end"
        alignItems="center"
      >
        <Grid item>{Presents}</Grid>
        <Grid item>{Provisoire}</Grid>
        <Grid item>{NonRepondu}</Grid>
        <Grid item>{Absents}</Grid>
      </Grid>
    </Container>
  )
}