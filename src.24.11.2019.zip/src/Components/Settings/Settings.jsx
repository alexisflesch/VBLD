import React, { Fragment } from 'react'
import Switch from '@material-ui/core/Switch';
import { Typography } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import Box from '@material-ui/core/Box';


export default function Settings() {

  const [checkedTri, setCheckedTri] = React.useState(true);
  const [checkedMeFirst, setCheckedMeFirst] = React.useState(true);
  const [name, setName] = React.useState('Nom à récupérer');
  const [firstname, setFirstName] = React.useState('Prénom à récupérer');


  function handleChangeName(event) {
    setName(event.target.value)
  }

  function handleChangeFirstName(event) {
    setName(event.target.value)
  }

  function handleChangeTri(event) {
    setCheckedTri(event.target.checked)
  }

  function handleChangeMeFirst(event) {
    setCheckedMeFirst(event.target.checked)
  }

  return (
    <Fragment>
      <InputLabel htmlFor="component-simple">Nom</InputLabel>
      <Input id="component-simple" value={name} onChange={handleChangeName} />
      <Box m={2} />
      <InputLabel htmlFor="component-simple">Prénom</InputLabel>
      <Input id="component-simple" value={firstname} onChange={handleChangeFirstName} />


      <Box m={2} />
      <Divider />
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Trier les listes par présence
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedTri} color='primary' onChange={handleChangeTri} value="checkBoxTri" />
        </Grid>
      </Grid>
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Afficher mon nom en premier
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedMeFirst} color='primary' onChange={handleChangeMeFirst} value="checkBoxMeFirst" />
        </Grid>
      </Grid>
    </Fragment>
  )
}