import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';

export default function Pots() {
  return (
    <Fragment>
      <h1>Autres événements</h1>
      <Typography>Pots, ... ?</Typography>
    </Fragment>
  )
}
