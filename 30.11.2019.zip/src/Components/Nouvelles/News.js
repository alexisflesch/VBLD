import React from 'react';
import { Typography } from '@material-ui/core';
import LogoVBLD from '../../images/logoVBLD.png';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles(theme => ({
  margins: {
    padding: theme.spacing(2),
    // margin: 0,
  },
}));


export default function News() {
  const classes = useStyles();

  return (
    <div className={classes.margins}>
      <Grid
        container
        direction="row"
        justify="center"
        alignItems="center"
      >
        <img src={LogoVBLD} alt='' width='150' />
      </Grid>
      <h3>Bienvenue !</h3>
      <Typography align='justify'>
        Si votre compte n'a pas encore été validé, vous n'avez
        pour l'instant pas accès à toutes les fonctionnalités.
        <br />
        En attendant, rendez-vous dans les paramètres pour
        renseigner vos informations personnelles.
      </Typography>
    </div>
  )
}