import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';

export default function Annuaire() {
  return (
    <Fragment>
      <h3>Annuaire</h3>
      <Typography>
        Bientôt ici, un annuaire (téléphonique, autre ?)
        en fonction de ce que les utilisateurs renseigneront
        dans les préférences.
      </Typography>
    </Fragment>
  )
}