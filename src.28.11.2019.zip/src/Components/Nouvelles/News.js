import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';


export default function News() {
  return (
    <Fragment>
      <h3>Bienvenue !</h3>
      <Typography align='justify'>
        Si votre compte n'a pas encore été validé, vous n'avez
        pour l'instant pas accès à toutes les fonctionnalités.
        <br />
        En attendant, rendez-vous dans les paramètres pour
        renseigner vos informations personnelles.
      </Typography>
    </Fragment>
  )
}