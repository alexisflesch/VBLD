import React, { Fragment, useContext } from 'react'
import Switch from '@material-ui/core/Switch';
import { Typography } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import Box from '@material-ui/core/Box';
import MailIcon from '@material-ui/icons/Mail';
import PhoneIcon from '@material-ui/icons/Phone';
import InputAdornment from '@material-ui/core/InputAdornment';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';


import GetUserData from '../UtilityScripts/FindStuff';
import FirebaseContext from '../Firebase/FirebaseContext'
import firebase from '../Firebase/firebase';


const useStyles = makeStyles(theme => ({
  margin: {
    marginBottom: theme.spacing(2),
  },
  button: {
    marginTop: theme.spacing(4),
  },
}));



export default function Settings() {

  const classes = useStyles();

  //Firebase stuff
  const { trees, loadings, errors, user } = useContext(FirebaseContext)
  const treeP = trees['treeP']
  const loadingP = loadings['loadingP']
  const errorP = errors['errorP']
  const userId = user['uid']
  const userData = GetUserData(treeP, loadingP, errorP)


  const [checkedTri, setCheckedTri] = React.useState(userData['triPresence']);
  const [checkedMeFirst, setCheckedMeFirst] = React.useState(userData['meFirst']);
  const [nom, setNom] = React.useState(userData['nom']);
  const [prenom, setPrenom] = React.useState(userData['prenom']);
  const [email, setEmail] = React.useState(userData['email']);
  const [telephone, setTelephone] = React.useState(userData['telephone']);


  function handleSave(event) {
    var myRef = firebase.database().ref('/users/' + userId)
    const nomT = nom ? nom : ''
    const prenomT = prenom ? prenom : ''
    const emailT = email ? email : ''
    const telephoneT = telephone ? telephone : ''
    const triPresence = checkedTri
    const meFirst = checkedMeFirst
    myRef.set({ nom: nomT, prenom: prenomT, email: emailT, telephone: telephoneT, triPresence, meFirst })
  }

  function handleChangeEmail(event) {
    setEmail(event.target.value)
  }

  function handleChangeTelephone(event) {
    setTelephone(event.target.value)
  }

  function handleChangeNom(event) {
    setNom(event.target.value)
  }

  function handleChangePrenom(event) {
    setPrenom(event.target.value)
  }

  function handleChangeTri(event) {
    setCheckedTri(event.target.checked)
  }

  function handleChangeMeFirst(event) {
    setCheckedMeFirst(event.target.checked)
  }

  return (
    <Fragment>
      <Typography variant='subtitle2'>
        Les informations ci-dessous servent à l'affichage de l'annuaire
        et des tableaux de présence.
      </Typography>
      <Box m={2} />
      <InputLabel htmlFor="component-simple">
        Nom
      </InputLabel>
      <Input id="component-simple"
        value={nom}
        onChange={handleChangeNom}
        className={classes.margin}
        fullWidth
      />
      <InputLabel htmlFor="component-simple">
        Prénom
      </InputLabel>
      <Input id="component-simple"
        value={prenom}
        onChange={handleChangePrenom}
        className={classes.margin}
        fullWidth
      />
      <InputLabel htmlFor="input-with-icon-adornment">
        Adresse email
        </InputLabel>
      <Input
        id="input-with-icon-adornment"
        startAdornment={
          <InputAdornment position="start">
            <MailIcon />
          </InputAdornment>
        }
        value={email}
        className={classes.margin}
        onChange={handleChangeEmail}
        fullWidth
      />
      <InputLabel htmlFor="input-with-icon-adornment">
        Téléphone
        </InputLabel>
      <Input
        id="input-with-icon-adornment"
        startAdornment={
          <InputAdornment position="start">
            <PhoneIcon />
          </InputAdornment>
        }
        value={telephone}
        className={classes.margin}
        onChange={handleChangeTelephone}
        fullWidth
      />
      <Box m={2} />
      <Divider />
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Trier les listes par présence
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedTri} color='primary' onChange={handleChangeTri} value="checkedTri" />
        </Grid>
      </Grid>
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Afficher mon nom en premier
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedMeFirst} color='primary' onChange={handleChangeMeFirst} value="checkedMeFirst" />
        </Grid>
      </Grid>
      <Button
        fullWidth
        variant="contained"
        color="primary"
        className={classes.button}
        onClick={handleSave}
      >
        Sauvegarder
      </Button>
    </Fragment>
  )
}