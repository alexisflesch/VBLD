function GetUserData(treeP, loadingP, errorP) {
  // Get info on a user using its personnal tree (/users/uid)
  // Inputs :
  //   - userId : a user unique id
  //   - treeU : the user tree (/users/) from the firebase database
  //   - loadingU : true if data is loading
  //   - errorU : true if an error occured (user trying to access something forbiddent, ...)
  // Ouput :
  //   - everything available ('nom', 'prenom', 'email', 'telephone' ...)
  if ((loadingP) || errorP || !treeP) return {}

  if (!treeP['nom']) {
    treeP['nom'] = ''
  }
  if (!treeP['prenom']) {
    treeP['prenom'] = ''
  }
  if (!treeP['telephone']) {
    treeP['telephone'] = ''
  }
  if (!treeP['email']) {
    treeP['email'] = ''
  }
  return treeP
}

export default GetUserData