import React, { Fragment } from 'react';





const sportifs = [
  { nom: 'Coach', present: 'Absent' },
  { nom: 'Isaline', present: 'Présent' },
  { nom: 'Fayot', present: 'Présent' },
  { nom: 'Maxime', present: 'Absent' }
];


