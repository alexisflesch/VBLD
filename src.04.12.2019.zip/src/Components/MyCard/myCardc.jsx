import React, { Fragment } from 'react';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import { makeStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import SportsVolleyballIcon from '@material-ui/icons/SportsVolleyball';
import Grid from '@material-ui/core/Grid';
import Avatar from '@material-ui/core/Avatar'
import BipBip from '../../images/bipbip2.png'
import Coyotte from '../../images/coyotte2.png'

import Selection from './Selection';

const useStyles = makeStyles(theme => ({
  appBar: {
    position: 'relative',
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1,
  },
  avatar: {
    marginTop: -11,
    padding: 0,
    // backgroundColor: "#e9f1f7",
  },
  button: {
    textTransform: 'none',
  },
  card: {
    marginTop: 5,
    marginBottom: 5,
    height: 50,
  },
  superCard: {
    marginTop: 5,
    marginBottom: 5,
    height: 50,
    // border: "thick double #32a1ce",
  },
  titre: {
    marginTop: -14,
    marginBottom: -7,
  },
}));


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function getBackgroundColor(present) {
  let backgroundColor;
  if (present === 'Présent(e)' || present === 'Oui') {
    backgroundColor = "#8ad5fb" //"#8fd0ff";
  }
  else if (present === 'Absent(e)' || present === 'Non') {
    backgroundColor = "#bcd4de" //blueGrey[200];
  }
  else if (present === 'Si besoin' || present === 'Provisoire') {
    backgroundColor = "#f5b829"; //"#ffd746";
  }
  else if (present === 'Match') {
    backgroundColor = '#ff7bdb'
  }
  else {
    backgroundColor = "#E9F1F7"; //blueGrey[50];
  }
  return backgroundColor
}


function generateOptions(options, sportif, setPresence, coach, hightlight) {
  var res = []
  let foo
  let inset
  for (const opt of options) {
    //Add volleyball icon to the current option
    if (opt === sportif['present']) {
      foo = (<ListItemIcon><SportsVolleyballIcon /></ListItemIcon>)
      inset = false
    }
    else {
      foo = ''
      inset = true
    }
    //Bipbip ou coyotte ?
    let opt2
    if (opt === 'Absent(e)') {
      if (sportif['civilite'] === 'bipbip') {
        opt2 = 'Absente'
      }
      else {
        opt2 = 'Absent'
      }
    }
    else if (opt === 'Présent(e)') {
      if (sportif['civilite'] === 'bipbip') {
        opt2 = 'Présente'
      }
      else {
        opt2 = 'Présent'
      }
    }
    else {
      opt2 = opt
    }
    //Est-ce le coach en train d'afficher qqn autre que lui-même ?
    let fun
    if (coach && !hightlight) {
      fun = () => { }
    }
    else {
      fun = () => setPresence(opt)
    }
    //Création de la liste
    res.push(
      <Fragment key={opt}>
        <ListItem button onClick={fun} style={{ backgroundColor: getBackgroundColor(opt) }}>
          {foo}
          <ListItemText inset={inset} primary={opt2} />
        </ ListItem>
        <Divider />
      </Fragment >
    )
  }
  return res
}


export default function MyCard(props) {
  const classes = useStyles();
  const { sportif, options, handleUpdateSportif, handleSaveCoach, highlight, coach } = props;
  const [open, setOpen] = React.useState(false);
  var backgroundColor = getBackgroundColor(sportif['present'])

  //Should we ever show the user's card differently
  if (highlight) {
    classes.myCard = classes.superCard
  }
  else {
    classes.myCard = classes.card
  }


  //Que faire quand on définit sa présence ?
  function setPresence(pres) {
    // Si on est sélectionné pour le match et qu'il
    // s'agit de l'affichage de l'entraînement, on ne change rien
    // (purement cosmétique, le joueur apparaissant en rose, cela permet
    // d'éviter un bug d'affichage)
    if (sportif['present'] !== 'Match') {
      sportif['present'] = pres
      handleUpdateSportif(sportif)
    }
    if (!coach) {
      handleClose()
    }
  }

  //Options de présence (à modifier pour le coach)
  var dialogOptions = generateOptions(options, sportif, setPresence, coach, highlight)


  //Sauvegarde depuis l'interface coach
  function handleSave() {
    handleSaveCoach(sportif)
    handleClose()
  }

  //On ne peut cliquer que sur son nom (sauf coach)
  const handleClickOpen = () => {
    if (highlight || coach) {
      setOpen(true);
    }
  };

  //Fermeture du tiroir
  const handleClose = () => {
    setOpen(false);
  };

  //Affichage de Présent ou Présente en fonction de la civilité
  var presentCiv = sportif['present'];
  if (presentCiv === 'Absent(e)') {
    if (sportif['civilite'] === 'bipbip') {
      presentCiv = 'Absente'
    }
    else {
      presentCiv = 'Absent'
    }
  }
  else if (presentCiv === 'Présent(e)') {
    if (sportif['civilite'] === 'bipbip') {
      presentCiv = 'Présente'
    }
    else {
      presentCiv = 'Présent'
    }
  }

  //S'agit-il du coach ?
  let coachStuff
  if (coach) {
    coachStuff = <Selection sportif={sportif} handleSave={handleSave} />
  }

  //S'agit-il d'un joueur sélectionné ?
  if (sportif['selectionne']['selectionne']) {
    //Choix de l'avatar
    let photo
    if (sportif['civilite'] === 'bipbip') {
      photo = BipBip
    }
    else {
      photo = Coyotte
    }
    var avatar = (
      <Avatar alt="X" src={photo} className={classes.avatar} />
    )
    //Renseignement du ou des postes
    var postes = []
    if (sportif['selectionne']['passe']) {
      postes.push('Passe')
    }
    if (sportif['selectionne']['centre']) {
      postes.push('Centre')
    }
    if (sportif['selectionne']['quatre']) {
      postes.push('Poste 4')
    }
    if (postes.length === 0) {
      presentCiv = 'Complet'
    }
    else {
      presentCiv = postes.join('/')
    }
  }

  return (
    <Container maxWidth="xs" >
      <Card className={classes.myCard} elevation={4}
        style={{ backgroundColor }} onClick={handleClickOpen}
      >
        <CardActionArea >
          <CardContent>
            <Grid
              container
              direction="row"
              justify="flex-start"
              alignItems="flex-start"
            >
              <Grid item xs={11}>
                <Typography className={classes.titre} variant="subtitle1">
                  {sportif['nom'] + ' ' + sportif['prenom']}
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {presentCiv}
                </Typography>
              </Grid>
              <Grid item xs={1}>
                {avatar}
              </Grid>
            </Grid>
          </CardContent>
        </CardActionArea>
      </Card>


      <Dialog fullScreen open={open} onClose={handleClose} TransitionComponent={Transition}>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close">
              <CloseIcon />
            </IconButton>
            <Typography variant="h6" className={classes.title}>
              {sportif['nom'] + ' ' + sportif['prenom']}
            </Typography>
          </Toolbar>
        </AppBar>
        <List>
          {dialogOptions}
        </List>
        {coachStuff}
      </Dialog>
    </Container >
  );
}