import React, { useContext } from 'react'
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';

import FirebaseContext from '../Firebase/FirebaseContext'
import { extractBranch } from '../UtilityScripts/TreeParsing'



const useStyles = makeStyles(theme => ({
  titre: {
    padding: 0,
    marginTop: 0,
    marginBottom: 0,
  }
}));

export default function LocationAndTime(props) {

  //Style
  const classes = useStyles();

  const fire = useContext(FirebaseContext)
  const { currentDateId, trainingOrMatch } = props;

  console.log('from locationAndTime')
  console.log(currentDateId)


  //Heure et lieu de la rencontre
  function findLocationAndTime(dateId) {
    if (!dateId) return ''
    if (fire['loadingTree']) return ''
    var subTree = extractBranch(fire, trainingOrMatch)
    console.log(trainingOrMatch)
    let location, time
    if (!subTree) {
      location = 'Lieu inconnu'
      time = 'Heure inconnue'
    }
    else if (!subTree[dateId]) {
      location = 'Lieu inconnu'
      time = 'Date inconnue'
      console.log("tentative d'accès à une date non enregistrée")
    }
    else {
      location = subTree[dateId]['lieu']
      time = subTree[dateId]['readableTime']
    }
    locationAndTime = (
      <Container maxWidth="xs" className={classes.titre}>
        <Grid
          container
          direction="row"
          justify="center"
          alignItems="baseline"
          spacing={3}
        >
          <Grid item>
            <h2>{location}</h2>
          </Grid>
          <Grid item>
            <h3>{time}</h3>
          </Grid>
        </Grid>
      </Container >
    )
    return locationAndTime
  }

  var locationAndTime = findLocationAndTime(currentDateId)

  return locationAndTime
}