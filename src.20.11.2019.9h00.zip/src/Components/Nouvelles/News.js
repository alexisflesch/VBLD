import React, { Fragment } from 'react';


export default function News() {
  return (
    <Fragment>
      Bienvenue sur la page des nouvelles !
    </Fragment>
  )
}