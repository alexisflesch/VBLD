function sortAuth() {
  return function (a, b) {
    if (a['authorized'] === b['authorized']) {
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      if (!a || !b) return 1
      else return foo.localeCompare(bar)
    }
    else {
      if (!a['authorized']) return -1
      else return 1
    }
  }
}

function mySort(triPresence, meFirst, uid) {
  //Inputs:
  //  - sportifs : a list of {nom, prenom, uid, present}
  //  - arg : a boolean
  if (!triPresence && meFirst) {
    return function (a, b) {
      if (a['uid'] === uid) return -1
      if (b['uid'] === uid) return 1
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      return foo.localeCompare(bar)
    }
  }
  else if (!triPresence && !meFirst) {
    return function (a, b) {
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      return foo.localeCompare(bar)
    }
  }
  else {
    return function (a, b) {
      if (meFirst && a['uid'] === uid) return -1
      if (meFirst && b['uid'] === uid) return 1
      if (a['present'] === b['present']) {
        var foo = a['nom'] + a['prenom']
        var bar = b['nom'] + b['prenom']
        return foo.localeCompare(bar)
      }
      else {
        if (a['present'] === 'Présent(e)') return -1
        else if (b['present'] === 'Présent(e)') return 1
        else if (a['present'] === 'Oui') return -1
        else if (b['present'] === 'Oui') return 1
        else if (a['present'] === 'Si besoin') return -1
        else if (b['present'] === 'Si besoin') return 1
        else if (a['present'] === 'Provisoire') return -1
        else if (b['present'] === 'Provisoire') return 1
        else if (a['present'] === 'Non renseigné') return -1
        else if (b['present'] === 'Non renseigné') return 1
        else if (a['present'] === 'Match') return -1
        else if (b['present'] === 'Match') return 1
      }
    }
  }
}


function findNextEvent(datesAndMore) {
  //Inputs:
  //  - datesAndMore : list of {dates, dateId, location}
  //Output:
  //  - {date, dateId, location} of next event after today
  var today = new Date()
  today.setHours(0, 0, 0, 0)

  //Is date list loaded ?
  if (!datesAndMore) return [];

  //In case there is no next event, return last event
  var { date, dateId, location } = datesAndMore[datesAndMore.length - 1]
  for (const dam of datesAndMore) {
    var bar = new Date(dam['date'])
    if (bar.setHours(0, 0, 0, 0) >= today) {
      date = new Date(dam['date'])
      dateId = dam['dateId']
      location = dam['location']
      break
    }
  }
  return { date, dateId, location }
}


function findCorrespondingTraining(dateId, treeE, loadingE) {
  //Inputs :
  // dateId : a date Id from the "entrainements" branch of the firebase tree
  // treeE : the "evenements" branch of the firebase tree
  // loadingE : true if treeE is still loading
  // errorE : true if an error occured while trying to connect to firebase
  //Ouput :
  // either a date id that matches the date of dateId in /evenements/matchs/ or false

  //Avoid problems
  if (loadingE || !treeE || !dateId) return false
  if (!treeE['entrainements']) return false
  if (!treeE['entrainements'][dateId]) return false

  //First, extract dates from the "entrainements" tree
  const { datesAndMore } = extractDates(treeE, loadingE, "matchs")

  //Find the date corresponding to dateId
  const dateNumEntrainement = treeE['entrainements'][dateId]['numericalDate']
  const dateEntrainement = new Date(dateNumEntrainement)
  const dateString = dateEntrainement.toDateString()


  //Then, try to find a match
  for (const dam of datesAndMore) {
    if (dam['date'].toDateString() === dateString) {//Match trouvé
      return dam['dateId']
    }
    else if (dam['date'].valueOf() > dateString + 86400000) {//Date dépassée
      return false
    }
  }
  return false
}


function extractDates(tree, loading, branchName) {
  //Inputs:
  //  - tree : a firebase tree
  //  - loading : true if data is still loading
  //  - branchName : a branch name ("entrainements", "matchs", "pots", ...)
  //Ouput:
  //  - list of {dates, dateId, location}
  //  - nextEvent (going from today)

  var vide = { 'datesAndMore': [], nextEvent: { 'date': 'fake date', 'dateId': 'fake date id', 'location': '' } }

  if (loading) return vide
  if (!tree) return vide

  var subTree = tree[branchName]
  if (!subTree) return vide

  var datesAndMore = []
  const keys = Object.keys(subTree)
  for (const dateId of keys) {
    if (dateId !== 'content') {
      var date = new Date(parseInt(subTree[dateId]['numericalDate']))
      // var location = subTree[dateId]['location']
      var domicile = subTree[dateId]['EquipeDomicile']
      var exterieur = subTree[dateId]['EquipeExterieur']
      datesAndMore.push({ date, dateId, domicile, exterieur })
    }
  }

  //Tri de la liste des dates par ordre chronologique
  datesAndMore.sort(function (a, b) {
    return a['date'].valueOf() - b['date'].valueOf();
  });

  //Recherche du prochain événement
  var nextEvent = findNextEvent(datesAndMore)
  var res = { datesAndMore, nextEvent }

  return res
}


function extractPresence(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId) {

  //Si "entrainement", on cherche s'il y a un match en même temps
  let dateId2
  if (branchName === 'entrainements') {
    dateId2 = findCorrespondingTraining(dateId, treeE, loadingE)
  }

  //Présence à l'événement
  const { sportifs, totaux } = extractPresenceOne(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId)

  //Présence au match qui a lieu en même temps (le cas échéant)
  if (dateId2) {
    const presM = extractPresenceOne(treeE, loadingE, treeW, loadingW, treeU, loadingU, "matchs", dateId2)
    const sportifsM = presM.sportifs
    for (const sportifM of sportifsM) {
      if (sportifM['selectionne'] && sportifM['selectionne']['selectionne']) {
        //La personne fait partie de la sélection
        //Si elle est inscrite à l'entraînement on note sa sélection
        //Et on modifie les totaux de l'entraînement si nécessaire
        for (const sportifE of sportifs) {
          if (sportifE['uid'] === sportifM['uid']) {
            //On ajoute les infos du coach
            sportifE['selectionne'] = sportifM['selectionne']
            //On modifie les totaux
            totaux[sportifE['present']]--
            totaux['Match']++
            //On modifie la présence du joueur
            sportifE['present'] = 'Match'
          }
        }
      }
    }
  }

  return { sportifs, totaux }
}


function extractPresenceOne(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId) {
  //Inputs:
  //  - treeE : main firebase tree (namely "evenements")
  //  - loadingE : true if data is still loading on treeE
  //  - treeW : whiteList users tree
  //  - loadingW : true if data is still loading on treeW
  //  - treeU : tree of all registered users (even not on whiteList)
  //  - loadingU : true if data is still loading on treeU
  //  - branchName : a branch name ("entrainements", "matchs", "pots", ...)
  //  - dateid : a dateid that (hopefully) exists in treeE['branchName']
  //Ouput : 
  //  - list of {nom, prenom, uid, present, selection : { selectionne, centre, passe, quatre} }
  //  - total number of whatever (present, absent, oui, non, si besoin)

  //En cas d'erreur ou de chargement des arbres
  var sportifs = []
  var totaux = {
    'Oui': 0, 'Présent(e)': 0,
    'Non': 0, 'Absent(e)': 0,
    'Si besoin': 0, 'Provisoire': 0,
    'Non renseigné': 0,
    'Match': 0,
  }
  const vide = { sportifs, totaux }

  if (loadingE || loadingW || loadingU) return vide

  if (!treeE) return vide
  var dateTree = treeE[branchName]
  if (!dateTree || !treeU) return vide

  //First, find the corresponding branch in dateTree
  var branch = dateTree[dateId]
  if (!branch) return vide

  //Then populate res list and totaux
  let keysInscrits
  if (branch['inscrits']) {
    keysInscrits = Object.keys(branch['inscrits'])
  }
  else {
    keysInscrits = []
  }
  //Find selection if it exists
  let keysSelection
  if (branch['selection']) {
    keysSelection = Object.keys(branch['selection'])
  }
  else {
    keysSelection = []
  }

  const keysUsers = Object.keys(treeW)
  for (const key of keysUsers) {
    var nom = treeU[key]['readOnly']['nom']
    var prenom = treeU[key]['readOnly']['prenom']
    var civilite = treeU[key]['readWrite']['civilite']
    var uid = key
    let present
    let selectionne
    //Si sportif a renseigné sa présence
    if (keysInscrits.includes(key)) {
      present = branch['inscrits'][key]['present']
      totaux[present]++
    }
    else {
      present = 'Non renseigné'
      totaux['Non renseigné']++
    }
    //Si coach a fait sa sélection
    if (keysSelection.includes(key)) {
      selectionne = branch['selection'][key]
      //On augment le nombre de sélectionnés
      if (branch['selection'][key]['selectionne']) {
        totaux['Match']++
      }
    }
    else {
      selectionne = {
        'selectionne': false,
        'quatre': false,
        'centre': false,
        'passe': false,
      }
    }
    sportifs.push({ nom, prenom, civilite, uid, present, selectionne })
  }
  return { sportifs, totaux }
}


function nombreSelections(treeE, loadingE, treeW, loadingW, dateId, sportifs) {
  //Inputs:
  //  - treeE : main firebase tree (namely "evenements")
  //  - loadingE : true if data is still loading on treeE
  //  - treeW : whiteList users tree
  //  - loadingW : true if data is still loading on treeW
  //  - dateid : a dateid that exists in treeE['matchs']
  //  - sportifs : a list of {nom, prenom, present, uid, ... }
  //Ouput : 
  //  - a list of {nom, prenom, present, uid, ... AND nbSelections}
  // where nbSelections is the number of selections before dateId


  //En cas d'erreur ou de chargement des arbres
  if (!sportifs || loadingE || loadingW || !treeE || !treeW) return []


  //Initialisation de nbSelections
  for (const sportif of sportifs) {
    sportif['nbSelections'] = 0
  }

  //Date du match en cours d'édition :
  //On ne regarde que les sélections antérieures
  if (!treeE['matchs'] || !treeE['matchs'][dateId] || !treeE['matchs'][dateId]['numericalDate']) {
    return sportifs
  }

  const currentDate = treeE['matchs'][dateId]['numericalDate']

  //On boucle sur les dates des matchs
  const { datesAndMore } = extractDates(treeE, loadingE, 'matchs')
  for (const dam of datesAndMore) {
    if (dam['date'].valueOf() >= currentDate) {
      break
    }
    else {
      //Il s'agit d'une date antérieure
      //On boucle sur les sélectionnés
      var selectionnes = treeE['matchs'][dam['dateId']]['selection']
      if (selectionnes) {
        var keys = Object.keys(selectionnes)
        for (const key of keys) {
          // On identifie le sportif grâce à son uid
          for (const sportif of sportifs) {
            if (sportif['uid'] === key) {
              // On met à jour le nombre de sélections
              sportif['nbSelections'] = sportif['nbSelections'] + selectionnes[key]['selectionne']
              break
            }
          }
        }
      }
    }
  }

  return sportifs


}


function findLocationAndTime(treeE, loadingE, branchName, dateId) {
  //Inputs:
  //  - treeE : main firebase tree (namely "evenements")
  //  - loadingE : true if data is still loading
  //  - branchName : a branchName ("entrainements", "matchs", "pots", ...)
  //  - dateId : a date id
  //Ouput : 
  //  - {time, domicile, exterieur}

  if (!dateId || loadingE || !treeE) return ''
  var subTree = treeE[branchName]

  let domicile, exterieur, time
  if (!subTree) {
    domicile = 'Match inconnu'
    time = 'Heure inconnue'
  }
  else if (!subTree[dateId]) {
    domicile = 'Match inconnu'
    time = 'Date inconnue'
  }
  else {
    domicile = subTree[dateId]['EquipeDomicile']
    exterieur = subTree[dateId]['EquipeExterieur']
    time = subTree[dateId]['readableTime']
  }

  return { domicile, exterieur, time }
}


function GetDirectoryData(treeU, treeW) {
  //Inputs:
  //  - treeU : firebase tree containing all users
  //  - treeW : firebase tree of white listed users
  //Ouput : 
  //  - list of users with everything : {'nom', 'prenom', 'email', 'telephone' ...}
  if (!treeU || !treeW) return []

  var res = []
  //Looping on whiteListed users
  const keysUsers = Object.keys(treeW)
  for (const key of keysUsers) {
    if (treeU[key]) {
      res.push({ ...treeU[key]['readOnly'], ...treeU[key]['readWrite'], 'uid': key })
    }
  }
  return res.sort(mySort('a-z', false, '0'))
}

function GetAdminData(treeU, treeW) {
  //Inputs:
  //  - treeU : firebase tree containing all users
  //  - treeW : firebase tree of white listed users
  //Ouput : 
  //  - list of ALL users with everything : {'nom', 'prenom', 'email', 'telephone' ...}
  //  - plus one important info : is user in whiteList or not ?
  //  - except admins ! So that an admin can't remove another admin
  if (!treeU || !treeW) return []

  let temp
  var res = []
  //Looping on ALL users
  const keysUsers = Object.keys(treeU)
  for (const key of keysUsers) {
    temp = Object.assign({}, treeU[key]);
    if (!temp['readOnly']['nom']) temp['readOnly']['nom'] = '?'
    if (!temp['readOnly']['prenom']) temp['readOnly']['prenom'] = '?'
    if (treeW[key]) {
      if (!treeW[key]['admin']) {
        res.push({ ...temp['readOnly'], ...temp['readWrite'], 'uid': key, 'authorized': true })
      }
    }
    else {
      res.push({ ...temp['readOnly'], ...temp['readWrite'], 'uid': key, 'authorized': false })
    }
  }
  return res.sort(sortAuth())
}

export default mySort
export { extractPresence, extractDates, mySort, findNextEvent, findLocationAndTime, GetDirectoryData, GetAdminData, findCorrespondingTraining, nombreSelections }