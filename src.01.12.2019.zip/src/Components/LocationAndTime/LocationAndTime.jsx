import React, { useContext } from 'react'
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';

import FirebaseContext from '../Firebase/FirebaseContext'
import { findLocationAndTime } from '../UtilityScripts/TreeParsing'

const useStyles = makeStyles(theme => ({
  titre: {
    padding: 0,
    marginTop: 0,
    marginBottom: 0,
  }
}));

export default function LocationAndTime(props) {
  //Style
  const classes = useStyles();
  const { trees, loadings } = useContext(FirebaseContext)
  const { currentDateId, trainingOrMatch } = props;

  //Heure et lieu de la rencontre
  const { location, time } = findLocationAndTime(trees['treeE'], loadings['loadingE'], trainingOrMatch, currentDateId)

  return (
    <div className={classes.titre}>
      <Grid
        container
        direction="row"
        justify="center"
        alignItems="baseline"
        spacing={0}
      >
        <Grid item>
          <h2>{location}</h2>
        </Grid>
        <Grid item xs={1} />
        <Grid item>
          <h3>{time}</h3>
        </Grid>
      </Grid>
    </div >
  )

}