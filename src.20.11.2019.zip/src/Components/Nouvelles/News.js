import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';


export default function News() {
  return (
    <Fragment>
      <h1>Bienvenue sur la page des nouvelles !</h1>
      <Typography>Utilisez l'icône de menu en haut à gauche pour naviguer.</Typography>
    </Fragment>
  )
}