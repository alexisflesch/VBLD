import React, { useContext } from 'react'
import MyCard from '../MyCard/myCardc'

import FirebaseContext from '../Firebase/FirebaseContext'
import { extractPresence2, mySort } from '../UtilityScripts/TreeParsing'

export default function ListeSportifs(props) {

  const fire = useContext(FirebaseContext)
  const { currentDateId, trainingOrMatch } = props;

  console.log('from listesportifs')
  console.log(currentDateId)
  let listeSportifs

  //Liste des options de présence
  let options
  if (trainingOrMatch === 'entrainements') {
    options = ['Présent(e)', 'Provisoire', 'Absent(e)']
  }
  else {
    options = ['Oui', 'Non', 'Si besoin']
  }

  function updateListSportifs(dateId) {
    //Fonction qui met à jour la liste des sportifs
    if (fire['loadingTree']) return
    var sportifs = extractPresence2(fire, trainingOrMatch, dateId)
    //Tri des sportifs
    if (fire['tri'] === 'a-z') {
      sportifs.sort(mySort('a-z'))
    }
    else {
      sportifs.sort(mySort('presence'))
    }
    return sportifs
  }

  function handleUpdateSportif(sportif) {
    //Fonction qui met à jour un sportif après modification éventuelle de sa présence
    var myRef = fire['firebase'].database().ref(trainingOrMatch).child(currentDateId).child('inscrits').child(sportif['uid'])
    myRef.set({ present: sportif['present'] })
  }


  var sportifs = updateListSportifs(currentDateId)

  //Affichage de la liste si elle existe
  if (sportifs.length === 0) {
    listeSportifs = ('Sélectionnez une date')
  }
  else {
    listeSportifs = (
      sportifs.map(sportif => <MyCard key={sportif['nom'] + sportif['prenom']}
        sportif={sportif}
        options={options}
        handleUpdateSportif={handleUpdateSportif} />)
    )
  }

  return (
    <div>
      {listeSportifs}
    </div>
  )
}