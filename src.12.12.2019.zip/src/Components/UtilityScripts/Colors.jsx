
export default function getBackgroundColor(present) {
  let backgroundColor;
  if (present === 'Présent(e)' || present === 'Oui') {
    backgroundColor = "#8ad5fb"
  }
  else if (present === 'Absent(e)' || present === 'Non') {
    backgroundColor = "#bcd4de"
  }
  else if (present === 'Si besoin' || present === 'Provisoire') {
    backgroundColor = "#f5b829";
  }
  else if (present === 'Match') {
    backgroundColor = '#ff7bdb'
  }
  else {
    backgroundColor = "#E9F1F7";
  }
  return backgroundColor
}