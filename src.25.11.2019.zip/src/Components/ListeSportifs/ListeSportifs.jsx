import React, { useContext } from 'react'
import MyCard from '../MyCard/myCardc'

import FirebaseContext from '../Firebase/FirebaseContext'
import firebase from '../Firebase/firebase';

import { extractPresence, mySort } from '../UtilityScripts/TreeParsing'

export default function ListeSportifs(props) {

  const { trees, loadings, tri } = useContext(FirebaseContext)
  const { currentDateId, trainingOrMatch } = props;

  let listeSportifs

  //Liste des options de présence
  let options
  if (trainingOrMatch === 'entrainements') {
    options = ['Présent(e)', 'Provisoire', 'Absent(e)']
  }
  else {
    options = ['Oui', 'Non', 'Si besoin']
  }

  function updateListSportifs(dateId) {
    //Fonction qui met à jour la liste des sportifs
    if (loadings['loadingW'] || loadings['loadingU']) return

    //Pour que ça soit lisible
    const { treeE, treeU, treeW } = trees;
    const { loadingE, loadingU, loadingW } = loadings;
    const branchName = trainingOrMatch

    var sportifs = extractPresence(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId)

    //Tri des sportifs
    if (tri === 'a-z') {
      sportifs.sort(mySort('a-z'))
    }
    else {
      sportifs.sort(mySort('presence'))
    }
    return sportifs
  }

  function handleUpdateSportif(sportif) {
    //Fonction qui met à jour un sportif après modification éventuelle de sa présence
    var myRef = firebase.database().ref("evenements/").child(trainingOrMatch).child(currentDateId).child('inscrits').child(sportif['uid'])
    myRef.set({ present: sportif['present'] })
  }


  var sportifs = updateListSportifs(currentDateId)

  //Affichage de la liste si elle existe
  if (sportifs.length === 0) {
    listeSportifs = ('Sélectionnez une date')
  }
  else {
    listeSportifs = (
      sportifs.map(sportif => <MyCard key={sportif['nom'] + sportif['prenom']}
        sportif={sportif}
        options={options}
        handleUpdateSportif={handleUpdateSportif} />)
    )
  }

  return (
    <div>
      {listeSportifs}
    </div>
  )
}