import React from 'react';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';

import CardHeader from '@material-ui/core/CardHeader';
import Avatar from '@material-ui/core/Avatar';
import Container from '@material-ui/core/Container';

import blueGrey from '@material-ui/core/colors/blueGrey';
import { useTheme } from '@material-ui/core/styles';


import { makeStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import UserInfo from './UserInfo2';

import ButtonsAdmin from './ButtonsAdmin';
import ButtonsNormal from './ButtonsNormal';


const useStyles = makeStyles(theme => ({
  appBar: {
    position: 'relative',
    marginBottom: 0,
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1,
  },
  action: {
    margin: theme.spacing(1),
    padding: 0,
  },
  card: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
  titre: {
    marginTop: -14,
    marginBottom: -7,
  }
}));


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});


function getBackgroundColor(theme, authorized) {
  let backgroundColor;
  if (authorized) {
    backgroundColor = theme.palette.primary.main;
  }
  else {
    backgroundColor = blueGrey[50];
  }
  return backgroundColor
}



export default function MyCard(props) {
  const classes = useStyles();
  const { sportif, boutons, authorized, handleClickAccept, handleClickBan } = props;
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };


  let Buttons
  if (boutons === 'normal') {
    Buttons = <ButtonsNormal handleClickAccept={handleClose} buttonName="Fermer" />
  }
  else if (boutons === 'admin') {
    Buttons = <ButtonsAdmin
      handleClickAccept={() => { handleClickAccept(); handleClose() }}
      handleClickBan={() => { handleClickBan(); handleClose() }}
    />
  }

  return (
    <Container maxWidth="xs" >
      <Card className={classes.card} elevation={4} onClick={handleClickOpen} >
        <CardActionArea>
          <CardHeader className={classes.action}
            avatar={
              <Avatar
                style={{ backgroundColor: getBackgroundColor(theme, authorized) }} >
                {sportif['nom'].substring(0, 1)}
              </ Avatar>
            }
            disableTypography
            title={<Typography >{sportif['nom'] + ' ' + sportif['prenom']} </Typography>}
          // subheader={sportif['email']}
          />
        </CardActionArea>
      </Card>

      <Dialog fullScreen open={open} onClose={handleClose} TransitionComponent={Transition}>

        <UserInfo
          nom={sportif['nom']}
          prenom={sportif['prenom']}
          email={sportif['email']}
          telephone={sportif['telephone']}
          civilite={sportif['civilite']}
        />

        <Box p={8} />
        {Buttons}

      </Dialog>
    </Container >
  );
}