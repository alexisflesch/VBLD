import React, { Fragment } from 'react';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';

import Container from '@material-ui/core/Container';

import blueGrey from '@material-ui/core/colors/blueGrey';
import amber from '@material-ui/core/colors/amber';
import teal from '@material-ui/core/colors/teal';

import { makeStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import SportsVolleyballIcon from '@material-ui/icons/SportsVolleyball';


const useStyles = makeStyles(theme => ({
  appBar: {
    position: 'relative',
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1,
  },
  align: {
    // margin: theme.spacing(1),
    // textAlign: 'left!',
  },
  button: {
    textTransform: 'none',
  },
  card: {
    marginTop: 5,
    marginBottom: 5,
    height: 50,
  },
  titre: {
    marginTop: -14,
    marginBottom: -7,
  }
}));


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});


export default function MyCard(props) {
  const classes = useStyles();
  const { sportif, options, handleUpdateSportif } = props;

  const [open, setOpen] = React.useState(false);


  function getBackgroundColor(present) {
    let backgroundColor;
    if (present === 'Présent(e)' || present === 'Oui') {
      backgroundColor = teal.A400;
    }
    else if (present === 'Absent(e)' || present === 'Non') {
      backgroundColor = blueGrey[200];
    }
    else if (present === 'Si besoin' || present === 'Provisoire') {
      backgroundColor = amber[500];
    }
    else {
      backgroundColor = blueGrey[50];
    }
    return backgroundColor
  }

  var backgroundColor = getBackgroundColor(sportif['present'])


  function generateOptions(options) {
    var res = []
    let foo
    let inset
    for (const opt of options) {
      //Add volleyball icon to the current option
      if (opt === sportif['present']) {
        foo = (<ListItemIcon><SportsVolleyballIcon /></ListItemIcon>)
        inset = false
      }
      else {
        foo = ''
        inset = true
      }
      res.push(
        <Fragment key={opt}>
          <ListItem button onClick={() => setPresence(opt)} style={{ backgroundColor: getBackgroundColor(opt) }}>
            {foo}
            <ListItemText inset={inset} primary={opt} />
          </ ListItem>
          <Divider />
        </Fragment >
      )
    }
    return res
  }

  var dialogOptions = generateOptions(options)

  const handleClickOpen = () => {
    console.log("opening")
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };


  function setPresence(pres) {
    sportif['present'] = pres
    handleUpdateSportif(sportif)
    handleClose()
  }

  return (
    <Container maxWidth="xs" >
      <Card className={classes.card} elevation={4}
        style={{ backgroundColor }} onClick={handleClickOpen}
      >
        <CardActionArea >
          <Grid
            container
            direction="row"
            justify="space-evenly"
            alignItems="center"
          >
            <Grid item xs={12}>
              <CardContent>
                <Typography className={classes.titre} variant="subtitle1">
                  {sportif['nom'] + ' ' + sportif['prenom']}
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {sportif['present']}
                </Typography>
              </CardContent>
            </Grid>
          </Grid>
        </CardActionArea>
      </Card>
      <Dialog fullScreen open={open} onClose={handleClose} TransitionComponent={Transition}>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close">
              <CloseIcon />
            </IconButton>
            <Typography variant="h6" className={classes.title}>
              {sportif['nom'] + ' ' + sportif['prenom']}
            </Typography>
          </Toolbar>
        </AppBar>
        <List>
          {dialogOptions}
        </List>
      </Dialog>
    </Container >
  );
}