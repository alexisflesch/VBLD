function mySort(arg) {
  //Inputs:
  //  - sportifs : a list of {nom, prenom, uid, present}
  //  - arg : 'a-z' or 'present'
  if (arg === 'a-z') {
    return function (a, b) {
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      return foo.localeCompare(bar)
    }
  }
  else {
    return function (a, b) {
      if (a['present'] === b['present']) {
        var foo = a['nom'] + a['prenom']
        var bar = b['nom'] + b['prenom']
        return foo.localeCompare(bar)
      }
      else {
        if (a['present'] === 'Présent(e)') return -1
        else if (b['present'] === 'Présent(e)') return 1
        else if (a['present'] === 'Oui') return -1
        else if (b['present'] === 'Oui') return 1
        else if (a['present'] === 'Si besoin') return -1
        else if (b['present'] === 'Si besoin') return 1
        else if (a['present'] === 'Provisoire') return -1
        else if (b['present'] === 'Provisoire') return 1
        else if (a['present'] === 'Non renseigné') return -1
        else if (b['present'] === 'Non renseigné') return 1
      }
    }
  }
}

function findNextEvent(datesAndMore) {
  //Inputs:
  //  - fire : main firebase context
  //  - type : "matchs" ou "entrainements"
  //Output:
  //  - date of next event after today
  var today = new Date()
  today.setHours(0, 0, 0, 0)
  let date, dateId, location
  //Is date list loaded ?
  for (const dam of datesAndMore) {
    var bar = new Date(dam['date'])
    if (bar.setHours(0, 0, 0, 0) >= today) {
      date = new Date(dam['date'])
      dateId = dam['dateId']
      location = dam['lieu']
      break
    }
  }
  return { date, dateId, location }
}

function extractDates(fire, type) {
  //Inputs:
  //  - fire : the context of the firebase
  //  - type : "entrainements", "matchs", ...
  //Ouput:
  //  - list of dates
  //  - list of {Date, dateId, location}

  var vide = { 'datesAndMore': [], nextEvent: { 'date': 'fake date', 'dateId': 'fake date id', 'location': '' } }

  if (fire['loadingTree']) return vide
  var tree = extractBranch(fire, type)
  if (!tree) return vide

  var datesAndMore = []
  const keys = Object.keys(tree)
  for (const dateId of keys) {
    if (dateId !== 'content') {
      var date = new Date(parseInt(tree[dateId]['numericalDate']))
      var location = tree[dateId]['lieu']
      datesAndMore.push({ date, dateId, location })
    }
  }

  //Tri de la liste des dates
  datesAndMore.sort(function (a, b) {
    return a['date'].valueOf() - b['date'].valueOf();
  });

  //Recherche du prochain événement
  var nextEvent = findNextEvent(datesAndMore)
  var res = { datesAndMore, nextEvent }

  return res
}

function extractBranch(fire, branch) {
  //Inputs:
  //  - fire : the context of the firebase
  //  - branch : a name ("users", "entrainements", "matchs", ... )
  //Ouput:
  //  - corresponding tree
  if (fire['loadingTree']) {
    return []
  }
  else {
    if (!fire['tree']) return []
    for (const subTree of fire['tree']) {
      if (subTree['content'] === branch) {
        return subTree
      }
    }
  }
}


function extractUsers(fire) {
  //Find branch 'users' in the main tree and extracts it
  return extractBranch(fire, 'users')
}


function extractPresence2(fire, type, dateid) {
  //Inputs :
  //  - fire : main firebase context
  //  - type : check for users registred at "date" in subtree "type" (entrainements", "match",...)
  //  - dateid : a dateid that (hopefully) exists in the subtree
  //Ouput : 
  //  - list of {nom, prenom, present}

  if (fire['loadingTree']) {
    return []
  }

  var dateTree = extractBranch(fire, type)
  var userTree = extractBranch(fire, 'users')

  if (!dateTree || !userTree) return []

  //First, find the corresponding branch in dateTree
  var branch = dateTree[dateid]
  if (!branch) return []

  //Then populate res list
  var res = []
  let keysInscrits
  if (branch['inscrits']) {
    keysInscrits = Object.keys(branch['inscrits'])
  }
  else {
    keysInscrits = []
  }
  const keysUsers = Object.keys(userTree)
  for (const key of keysUsers) {
    if (key !== 'content') {
      var nom = userTree[key]['nom']
      var prenom = userTree[key]['prenom']
      var uid = key
      let present
      if (keysInscrits.includes(key)) {
        present = branch['inscrits'][key]['present']
      }
      else {
        present = 'Non renseigné'
      }
      res.push({ nom, prenom, uid, present })
    }
  }
  return res
}


function extractPresence(tree, date, type) {
  //Inputs :
  //  - tree : a tree of users
  //  - date : a date to check
  //  - type : check for presence at "date" in subtree "type" (entrainements", "match",...)
  //  - Given a tree of users, returns a list of {name, present}
  //Ouput : 
  //  - list of {name, present}

  var sportifs = []

  const keys = Object.keys(tree)
  for (const key of keys) {
    if (key !== 'content') {
      var name = tree[key]['name']
      var present = '?'
      var subTree = tree[key][type]
      for (const d in subTree) {
        var bar = new Date(parseInt(subTree[d]['numericalDate']))
        if (date.toDateString() === bar.toDateString()) {
          present = subTree[d]['present']
        }
      }
      sportifs.push({ name, present })
    }
  }
  return sportifs
}


export default extractUsers
export { extractUsers, extractPresence2, extractPresence, extractDates, extractBranch, mySort, findNextEvent }