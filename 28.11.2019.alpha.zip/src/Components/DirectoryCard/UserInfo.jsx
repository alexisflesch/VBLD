import React, { Fragment } from 'react'
import MailIcon from '@material-ui/icons/Mail';
import PhoneIcon from '@material-ui/icons/Phone';
import InputAdornment from '@material-ui/core/InputAdornment';

import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import { makeStyles } from '@material-ui/core/styles';


import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';


const useStyles = makeStyles(theme => ({
  margin: {
    marginBottom: theme.spacing(2),
  },
}));


export default function UserInfo(props) {
  const classes = useStyles();
  const { nom, prenom, email, telephone, disabled, handleChangeNom,
    handleChangePrenom, handleChangeTelephone, handleChangeEmail,
    civilite, handleChangeCivilite } = props;

  return (
    <Fragment>
      <FormLabel component="legend">Civilité</FormLabel>
      <RadioGroup aria-label="position" name="position" value={civilite} onChange={handleChangeCivilite} row>
        <FormControlLabel
          value="bipbip"
          control={<Radio color="primary" />}
          label="BipBip"
          labelPlacement="end"
        />
        <FormControlLabel
          value="coyotte"
          control={<Radio color="primary" />}
          label="Coyotte"
          labelPlacement="end"
        />
      </RadioGroup>

      <InputLabel htmlFor="component-simple">
        Nom
      </InputLabel>
      <Input id="component-simple"
        value={nom}
        className={classes.margin}
        fullWidth
        disabled={disabled}
        onChange={handleChangeNom}
      />
      <InputLabel htmlFor="component-simple">
        Prénom
      </InputLabel>
      <Input id="component-simple"
        value={prenom}
        className={classes.margin}
        fullWidth
        onChange={handleChangePrenom}
        disabled={disabled}
      />
      <InputLabel htmlFor="input-with-icon-adornment">
        Adresse email
        </InputLabel>
      <Input
        id="input-with-icon-adornment"
        startAdornment={
          <InputAdornment position="start">
            <MailIcon />
          </InputAdornment>
        }
        value={email}
        className={classes.margin}
        fullWidth
        disabled={disabled}
        onChange={handleChangeEmail}
      />
      <InputLabel htmlFor="input-with-icon-adornment">
        Téléphone
        </InputLabel>
      <Input
        id="input-with-icon-adornment"
        startAdornment={
          <InputAdornment position="start">
            <PhoneIcon />
          </InputAdornment>
        }
        value={telephone}
        className={classes.margin}
        fullWidth
        disabled={disabled}
        onChange={handleChangeTelephone}
      />
    </Fragment >
  )
}