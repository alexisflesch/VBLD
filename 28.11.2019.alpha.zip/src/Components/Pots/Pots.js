import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';

export default function Pots() {
  return (
    <Fragment>
      <Typography>Onglet réservé à l'organisation des pots :
        fonctionnalité à venir, soyez patients !
      </Typography>
    </Fragment>
  )
}
