import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';

import Container from '@material-ui/core/Container';

import lightBlue from '@material-ui/core/colors/lightBlue';
import blueGrey from '@material-ui/core/colors/blueGrey';
import amber from '@material-ui/core/colors/amber';


const useStyles = makeStyles({
  card: {
    marginTop: 5,
    marginBottom: 5,
    height: 50,
  },
  titre: {
    marginTop: -14,
    marginBottom: -7,
  }
});

export default function MyCard(props) {
  const classes = useStyles();
  const { sportif, present } = props;
  let backgroundColor;
  let textPresent;

  switch (present) {
    case 'oui':
      backgroundColor = lightBlue[200];
      textPresent = 'Présent';
      break;
    case 'non':
      backgroundColor = blueGrey[200];
      textPresent = 'Absent';
      break;
    case 'si besoin':
      textPresent = 'Si besoin';
      backgroundColor = amber[200];
      break;
    default:
      textPresent = 'Non répondu'
      backgroundColor = blueGrey[50];
  }

  return (
    <Container maxWidth="xs" >
      <Card className={classes.card} elevation={4}
        style={{ backgroundColor }}
      >
        <CardActionArea>
          <Grid
            container
            direction="row"
            justify="space-evenly"
            alignItems="center"
          >
            {/* <Grid item xs={2}>
              &nbsp;
            </Grid> */}
            <Grid item xs={12}>
              <CardContent>
                <Typography className={classes.titre} variant="subtitle1">
                  {sportif}
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {textPresent}
                </Typography>
              </CardContent>
            </Grid>
          </Grid>
        </CardActionArea>
      </Card>
    </Container >
  );
}