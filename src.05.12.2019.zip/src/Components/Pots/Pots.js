import React from 'react';
import Container from '@material-ui/core/Container';
import Box from '@material-ui/core/Box';
import { Typography } from '@material-ui/core';

export default function Pots() {
  return (
    <Container maxWidth="xs" >
      <Box p={2} />
      <Typography align='justify'>
        Onglet réservé à l'organisation des pots :
        fonctionnalité à venir, soyez patients !
      </Typography>
    </Container>
  )
}
