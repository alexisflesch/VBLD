import React from 'react';
import ResponsiveDrawer from '../Drawer/MyDrawer'

import Matchs from '../Matchs/Matchs';
import News from '../Nouvelles/News';
import Autres from '../Autres/Autres';
import Entrainements from '../Entrainements/Entrainements';

import firebase from '../Firebase/firebase';

import { FirebaseProvider } from '../Firebase/FirebaseContext'
import { useListVals } from 'react-firebase-hooks/database';
import SortMenu from '../SortMenu/SortMenu'


function App() {

  //Firebase stuff : will be put in FirebaseContext later
  const [tree, loadingTree, errorTree] = useListVals(firebase.database().ref('/'));

  //Values to pass to the drawer
  const [mainDiv, setMainDiv] = React.useState(<Entrainements tree={tree} trainingOrMatch="entrainements" />);
  const [pageName, setPageName] = React.useState('Entraînements');

  //Icône pour trier les sportifs ('a-z' ou 'presence')
  //On ajoutera dans le contexte principal un booléen qui passera à true quand il faudra trier
  const [menu, setMenu] = React.useState(<SortMenu />);
  const [tri, setTri] = React.useState('a-z')

  function handleDivChange(newDiv) {
    var futureDiv = "";
    var futureName = "";
    var futureMenu = "";
    if (newDiv === "news") {
      futureDiv = <News />
      futureName = "Nouvelles"
    }
    else if (newDiv === "matchs") {
      futureDiv = <Entrainements trainingOrMatch="matchs" />
      futureName = "Matchs"
      futureMenu = <SortMenu />
    }
    else if (newDiv === "entrainements") {
      futureDiv = <Entrainements trainingOrMatch="entrainements" />
      futureName = "Entraînements"
      futureMenu = <SortMenu />
    }
    else if (newDiv === "autres") {
      futureDiv = <Autres />
      futureName = "Autres"
    }
    console.log("Changement de fenêtre")
    console.log(newDiv);
    setMainDiv(futureDiv);
    setPageName(futureName);
    setMenu(futureMenu)
  }



  return (
    <FirebaseProvider value={{ tree, loadingTree, errorTree, firebase, tri, setTri }}>
      <div>
        <ResponsiveDrawer
          div={mainDiv}
          pageName={pageName}
          handleChange={handleDivChange}
          menu={menu}
        />
      </div>
    </FirebaseProvider>
  );
}

export default App;