import React, { Fragment } from 'react';
import { Typography } from '@material-ui/core';


export default function News() {
  return (
    <Fragment>
      <h3>Bienvenue !</h3>
      <Typography>
        Si votre compte n'a pas encore été validé, vous n'avez
        pour l'instant pas accès à toutes les fonctionnalités.
        Vous pouvez cependant déjà renseigner vos informations personnelles.
      </Typography>
    </Fragment>
  )
}