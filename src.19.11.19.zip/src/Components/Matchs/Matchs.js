import React, { Fragment } from 'react';
import FullScreenDialog from '../ButtonWithDialog/buttonWithDialog';
import MaterialUIPickers from '../DatePicker/datePicker';


export default function Matchs() {
    return (
        <Fragment>
            <MaterialUIPickers />
            <br />
            <FullScreenDialog sportif='Maxime' present='si besoin' />
            <FullScreenDialog sportif='Alexis' present='present' />
            <FullScreenDialog sportif='Isaline' present='absent' />
            <FullScreenDialog sportif='Coach' present='present' />
            <FullScreenDialog sportif='Gwen' present='present' />
            <FullScreenDialog sportif='Sam' present='?' />
        </Fragment>
    )
}