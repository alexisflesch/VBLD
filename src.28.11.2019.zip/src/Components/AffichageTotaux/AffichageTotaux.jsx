import React, { Fragment } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import blueGrey from '@material-ui/core/colors/blueGrey';
import Grid from '@material-ui/core/Grid';
import { Typography } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  avatarOui: {
    backgroundColor: "#8fd0ff",
    color: "black",
    width: 30,
    height: 30,
  },
  avatarNonRepondu: {
    backgroundColor: blueGrey[50],
    color: "black",
    width: 30,
    height: 30,
  },
  avatarSiBesoin: {
    backgroundColor: "#ffd746",
    color: "black",
    width: 30,
    height: 30,
  },
  avatarAbsent: {
    backgroundColor: blueGrey[200],
    color: "black",
    width: 30,
    height: 30,
  }
}));

export default function AffichageTotaux(props) {
  const classes = useStyles();
  const { totaux } = props;

  //On complète les totaux pour éviter les erreurs
  const possibilites = ['Présent(e)', 'Oui', 'Si besoin', 'Provisoire', 'Non renseigné', 'Non', 'Absent(e)']
  for (const poss of possibilites) {
    if (!totaux[poss]) {
      totaux[poss] = 0
    }
  }
  const Presents = (
    <Avatar className={classes.avatarOui} >
      <Typography>
        {totaux['Oui'] + totaux['Présent(e)']}
      </Typography>
    </ Avatar>
  )
  const Provisoire = (
    <Avatar className={classes.avatarSiBesoin} >
      <Typography>
        {totaux['Provisoire'] + totaux['Si besoin']}
      </Typography>
    </ Avatar>
  )
  const NonRepondu = (
    <Avatar className={classes.avatarNonRepondu} >
      <Typography>
        {totaux['Non renseigné']}
      </Typography>
    </ Avatar>
  )
  const Absents = (
    <Avatar className={classes.avatarAbsent} >
      <Typography>
        {totaux['Non'] + totaux['Absent(e)']}
      </Typography>
    </ Avatar>
  )

  return (
    <Fragment>
      <Grid
        container
        direction="row"
        justify="flex-end"
        alignItems="center"
      >
        <Grid item>{Presents}</Grid>
        <Grid item>{Provisoire}</Grid>
        <Grid item>{NonRepondu}</Grid>
        <Grid item>{Absents}</Grid>
      </Grid>
    </Fragment>
  )
}