function GetUserData(treeP, loadingP, errorP) {
  // Get info on a user using its personnal tree (/users/uid)
  // Inputs :
  //   - userId : a user unique id
  //   - treeU : the user tree (/users/) from the firebase database
  //   - loadingU : true if data is loading
  //   - errorU : true if an error occured (user trying to access something forbiddent, ...)
  // Ouput :
  //   - everything available ('nom', 'prenom', 'email', 'telephone' ...)
  if ((loadingP) || errorP || !treeP) return {}

  if (!treeP['readOnly']['nom']) {
    treeP['readOnly']['nom'] = ''
  }
  if (!treeP['readOnly']['prenom']) {
    treeP['readOnly']['prenom'] = ''
  }
  if (!treeP['readWrite']['telephone']) {
    treeP['telephone'] = ''
  }
  if (!treeP['readWrite']['email']) {
    treeP['email'] = ''
  }
  var res = {}
  res = Object.assign(res, treeP['readOnly'])
  res = Object.assign(res, treeP['readWrite'])
  return res
}


function isAdmin(treeW, loadingTreeW, errorTreeW, userId) {
  if (loadingTreeW || errorTreeW) return false
  if (!treeW[userId]) return false
  if (treeW[userId]['role'] === 'admin') return true
}


export default GetUserData
export { isAdmin }