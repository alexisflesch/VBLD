import React, { useContext } from 'react';
import MaterialUIPickers from '../DatePicker/datePicker';
import Grid from '@material-ui/core/Grid'

import FirebaseContext from '../Firebase/FirebaseContext'
import { extractDates } from '../UtilityScripts/TreeParsing'

import ListeSportifs from '../ListeSportifs/ListeSportifs'
import LocationAndTime from '../LocationAndTime/LocationAndTime'
import LoadingDiv from '../LoadingDiv/LoadingDiv'
import AffichageTotaux from '../AffichageTotaux/AffichageTotaux'
import { makeStyles } from '@material-ui/core/styles';
import { extractPresencePot } from '../UtilityScripts/TreeParsing'
import Summary from './Summary'



const useStyles = makeStyles(theme => ({
  margins: {
    paddingTop: theme.spacing(1),
    margin: 0,
  },
}));



export default function Pots() {
  const classes = useStyles();

  //Context de firebase
  const { trees, loadings } = useContext(FirebaseContext)

  //Listes des dates des pots (à donner au calendrier ensuite)
  var { datesAndMore, nextEvent } = extractDates(trees['treeE'], loadings['loadingE'], "pots")

  //Date du prochain événement
  var [date, dateId] = [nextEvent['date'], nextEvent['dateId']]

  //State passé au calendrier qui permettra de faire remonter l'info
  //si un changement de date a eu lieu
  const [currentDateId, setCurrentDateId] = React.useState(dateId)

  function findTotaux(dateId) {
    //Fonction qui met à jour les totaux

    //Pour que ça soit lisible
    const { treeE, treeU, treeW } = trees;
    const { loadingE, loadingU, loadingW } = loadings;

    //Les totaux pour le pot
    var { totaux, summary } = extractPresencePot(treeE, loadingE, treeW, loadingW, treeU, loadingU, dateId)

    return { totaux, summary }
  }

  //Infobulles avec le nombre de présents
  const { totaux, summary } = findTotaux(currentDateId)


  // Below is a fix needed if <matchs /> is the first thing
  // the app shows. Maybe not need if users have to log in
  // currentDateId is not properly initialized because FirebaseContext
  // is initialized with a fake date while loading.
  // When the true initial value arrives, the react Hook waits for
  // the next render to update it
  // Quick and dirty fix
  if (currentDateId === 'fake date id' && dateId !== 'fake date id') {
    setCurrentDateId(dateId)
  }


  if (loadings['loadingE']) {
    return <LoadingDiv />
  }
  else {
    return (
      <div className={classes.margins}>
        <Grid
          container
          direction="row"
          justify="space-between"
          alignItems="center"
          spacing={0}
        >
          <Grid item>
            <Summary summary={summary} />
          </Grid>
          <Grid item>
            <AffichageTotaux totaux={totaux} />
          </Grid>
        </Grid>
        <MaterialUIPickers
          currentDate={date}
          currentDateId={currentDateId}
          setCurrentDateId={setCurrentDateId}
          datesAndMore={datesAndMore}
        />

        {/* <Grid
          container
          direction="row"
          justify="center"
          alignItems="center"
          spacing={0}
        >
          <Grid item> */}
        <LocationAndTime
          currentDate={date}
          currentDateId={currentDateId}
          trainingOrMatch="pots"
        />
        {/* </Grid>
          <Grid item xs={1}>
            <Summary summary={summary} />
          </Grid>
        </Grid> */}


        <ListeSportifs
          currentDateId={currentDateId}
          trainingOrMatch="pots"
        />
      </div >
    )
  }
}
