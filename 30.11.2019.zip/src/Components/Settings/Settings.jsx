import React, { useContext } from 'react';
import { makeStyles } from '@material-ui/core/styles';

import Switch from '@material-ui/core/Switch';
import { Typography } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import ButtonsNormal from '../DirectoryCard/ButtonsNormal';
import Container from '@material-ui/core/Container';
import Snackbar from '@material-ui/core/Snackbar';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';

import GetUserData from '../UtilityScripts/FindStuff';
import FirebaseContext from '../Firebase/FirebaseContext'
import firebase from '../Firebase/firebase';

import UserInfo from '../DirectoryCard/UserInfo';


const useStyles = makeStyles(theme => ({
  close: {
    padding: theme.spacing(0.5),
  },
  icon: {
    fontSize: 20,
  },
  info: {
    backgroundColor: theme.palette.primary.main,
  },
  message: {
    display: 'flex',
    alignItems: 'center',
  },
}));


export default function Settings() {
  const classes = useStyles();

  //Firebase stuff
  const { trees, loadings, errors, user, setTri } = useContext(FirebaseContext)
  const treeP = trees['treeP']
  const loadingP = loadings['loadingP']
  const errorP = errors['errorP']
  const userId = user['uid']
  const userData = GetUserData(treeP, loadingP, errorP)


  const [checkedTri, setCheckedTri] = React.useState(userData['triPresence']);
  const [checkedMeFirst, setCheckedMeFirst] = React.useState(userData['meFirst']);
  const [nom, setNom] = React.useState(userData['nom']);
  const [prenom, setPrenom] = React.useState(userData['prenom']);
  const [email, setEmail] = React.useState(userData['email']);
  const [telephone, setTelephone] = React.useState(userData['telephone']);
  const [civilite, setCivilite] = React.useState(userData['civilite']);

  //SnackBar
  const [openBar, setOpenBar] = React.useState(false);

  function handleSave(event) {
    var myRef = firebase.database().ref('/users/' + userId)
    const nomT = nom ? nom : ''
    const prenomT = prenom ? prenom : ''
    const emailT = email ? email : ''
    const telephoneT = telephone ? telephone : ''
    const triPresence = checkedTri
    const meFirst = checkedMeFirst
    myRef.set({
      nom: nomT,
      prenom: prenomT,
      email: emailT,
      telephone: telephoneT,
      triPresence,
      meFirst,
      civilite
    })
    if (checkedTri) {
      setTri('presence')
    }
    else {
      setTri('a-z')
    }
    setOpenBar(true)
  }

  function handleCloseBar(event, reason) {
    if (reason === 'clickaway') {
      return;
    }
    setOpenBar(false);
  };


  function handleChangeCivilite(event) {
    setCivilite(event.target.value)
  }

  function handleChangeEmail(event) {
    setEmail(event.target.value)
  }

  function handleChangeTelephone(event) {
    setTelephone(event.target.value)
  }

  function handleChangeNom(event) {
    setNom(event.target.value)
  }

  function handleChangePrenom(event) {
    setPrenom(event.target.value)
  }

  function handleChangeTri(event) {
    setCheckedTri(event.target.checked)
  }

  function handleChangeMeFirst(event) {
    setCheckedMeFirst(event.target.checked)
  }

  return (
    <Container maxWidth="xs" >

      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        open={openBar}
        autoHideDuration={6000}
        onClose={handleCloseBar}
        ContentProps={{
          'aria-describedby': 'message-id',
        }}
        message={<span id="message-id">
          Paramètres sauvegardés
          </span>}
        action={[
          <IconButton
            key="close"
            aria-label="close"
            color="inherit"
            className={classes.close}
            onClick={handleCloseBar}
          >
            <CloseIcon />
          </IconButton>,
        ]}
      />

      <Box m={2} />
      <UserInfo
        civilite={civilite} handleChangeCivilite={handleChangeCivilite}
        nom={nom} handleChangeNom={handleChangeNom}
        prenom={prenom} handleChangePrenom={handleChangePrenom}
        email={email} handleChangeEmail={handleChangeEmail}
        telephone={telephone} handleChangeTelephone={handleChangeTelephone}
      />
      <Box m={2} />
      {/* <Divider /> */}
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Trier les listes par présence
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedTri} color='primary' onChange={handleChangeTri} value="checkedTri" />
        </Grid>
      </Grid>
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography>
            Afficher mon nom en premier
      </Typography>
        </Grid>
        <Grid item xs={2}>
          <Switch checked={checkedMeFirst} color='primary' onChange={handleChangeMeFirst} value="checkedMeFirst" />
        </Grid>
      </Grid>


      <Box p={2} />
      <ButtonsNormal buttonName="Sauvegarder" handleClickAccept={handleSave} />
    </Container>
  )
}