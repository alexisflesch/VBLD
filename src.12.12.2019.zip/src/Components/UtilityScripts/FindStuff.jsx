import mySort from './TreeParsing'


function GetUserData(treeP, loadingP, errorP) {
  // Get info on a user using its personnal tree (/users/uid)
  // Inputs :
  //   - userId : a user unique id
  //   - treeU : the user tree (/users/) from the firebase database
  //   - loadingU : true if data is loading
  //   - errorU : true if an error occured (user trying to access something forbiddent, ...)
  // Ouput :
  //   - everything available ('nom', 'prenom', 'email', 'telephone' ...)
  if ((loadingP) || errorP || !treeP) return {}

  if (!treeP['readOnly']['nom']) {
    treeP['readOnly']['nom'] = ''
  }
  if (!treeP['readOnly']['prenom']) {
    treeP['readOnly']['prenom'] = ''
  }
  if (!treeP['readWrite']['telephone']) {
    treeP['telephone'] = ''
  }
  if (!treeP['readWrite']['email']) {
    treeP['email'] = ''
  }

  if (!treeP['readWrite']['trustedUsers']) {
    treeP['readWrite']['trustedUsers'] = {}
  }

  return { ...treeP['readOnly'], ...treeP['readWrite'] }
}


function isAdmin(treeW, loadingTreeW, errorTreeW, userId) {
  if (loadingTreeW || errorTreeW) return false
  if (!treeW[userId]) return false
  return treeW[userId]['admin']
}

function getSportifs(treeW, loadingW, errorW, treeU, loadingU, errorU, userId) {
  if (loadingW || errorW || loadingU || errorU || !treeU || !treeW) return []

  var res = []
  const keys = Object.keys(treeW)
  for (const key of keys) {
    if (key === userId) continue //Ignore current user
    if (!treeU[key]) continue  //Should never happen
    var nom = treeU[key]['readOnly']['nom']
    var prenom = treeU[key]['readOnly']['prenom']
    var uid = key
    res.push({ nom, prenom, uid })
  }
  res.sort(mySort(false, false, ''))
  return res
}


export default GetUserData
export { isAdmin, getSportifs }