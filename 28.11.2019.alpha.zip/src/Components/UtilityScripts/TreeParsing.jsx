function sortAuth() {
  return function (a, b) {
    if (a['authorized'] === b['authorized']) {
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      if (!a || !b) return 1
      else return foo.localeCompare(bar)
    }
    else {
      if (!a['authorized']) return -1
      else return 1
    }
  }
}

function mySort(arg, meFirst, uid) {
  //Inputs:
  //  - sportifs : a list of {nom, prenom, uid, present}
  //  - arg : 'a-z' or 'present'
  if (arg === 'a-z' && meFirst) {
    return function (a, b) {
      if (a['uid'] === uid) return -1
      if (b['uid'] === uid) return 1
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      return foo.localeCompare(bar)
    }
  }
  else if (arg === 'a-z' && !meFirst) {
    return function (a, b) {
      var foo = a['nom'] + a['prenom']
      var bar = b['nom'] + b['prenom']
      return foo.localeCompare(bar)
    }
  }
  else {
    return function (a, b) {
      if (meFirst && a['uid'] === uid) return -1
      if (meFirst && b['uid'] === uid) return 1
      if (a['present'] === b['present']) {
        var foo = a['nom'] + a['prenom']
        var bar = b['nom'] + b['prenom']
        return foo.localeCompare(bar)
      }
      else {
        if (a['present'] === 'Présent(e)') return -1
        else if (b['present'] === 'Présent(e)') return 1
        else if (a['present'] === 'Oui') return -1
        else if (b['present'] === 'Oui') return 1
        else if (a['present'] === 'Si besoin') return -1
        else if (b['present'] === 'Si besoin') return 1
        else if (a['present'] === 'Provisoire') return -1
        else if (b['present'] === 'Provisoire') return 1
        else if (a['present'] === 'Non renseigné') return -1
        else if (b['present'] === 'Non renseigné') return 1
      }
    }
  }
}

function findNextEvent(datesAndMore) {
  //Inputs:
  //  - datesAndMore : list of {dates, dateId, location}
  //Output:
  //  - {date, dateId, location} of next event after today
  var today = new Date()
  today.setHours(0, 0, 0, 0)

  //Is date list loaded ?
  if (!datesAndMore) return [];

  //In case there is no next event, return last event
  var { date, dateId, location } = datesAndMore[datesAndMore.length - 1]
  for (const dam of datesAndMore) {
    var bar = new Date(dam['date'])
    if (bar.setHours(0, 0, 0, 0) >= today) {
      date = new Date(dam['date'])
      dateId = dam['dateId']
      location = dam['location']
      break
    }
  }
  return { date, dateId, location }
}

function extractDates(tree, loading, branchName) {
  //Inputs:
  //  - tree : a firebase tree
  //  - loading : true if data is still loading
  //  - branchName : a branch name ("entrainements", "matchs", "pots", ...)
  //Ouput:
  //  - list of {dates, dateId, location}
  //  - nextEvent (going from today)

  var vide = { 'datesAndMore': [], nextEvent: { 'date': 'fake date', 'dateId': 'fake date id', 'location': '' } }

  if (loading) return vide
  if (!tree) return vide

  var subTree = tree[branchName]
  if (!subTree) return vide

  var datesAndMore = []
  const keys = Object.keys(subTree)
  for (const dateId of keys) {
    if (dateId !== 'content') {
      var date = new Date(parseInt(subTree[dateId]['numericalDate']))
      var location = subTree[dateId]['location']
      datesAndMore.push({ date, dateId, location })
    }
  }

  //Tri de la liste des dates par ordre chronologique
  datesAndMore.sort(function (a, b) {
    return a['date'].valueOf() - b['date'].valueOf();
  });

  //Recherche du prochain événement
  var nextEvent = findNextEvent(datesAndMore)
  var res = { datesAndMore, nextEvent }

  return res
}


function extractPresence(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId) {
  //Inputs:
  //  - treeE : main firebase tree (namely "evenements")
  //  - loadingE : true if data is still loading on treeE
  //  - treeW : whiteList users tree
  //  - loadingW : true if data is still loading on treeW
  //  - treeU : tree of all registered users (even not on whiteList)
  //  - loadingU : true if data is still loading on treeU
  //  - branchName : a branch name ("entrainements", "matchs", "pots", ...)
  //  - fire : main firebase context
  //  - type : check for users registred at "date" in subtree "type" (entrainements", "match",...)
  //  - dateid : a dateid that (hopefully) exists in treeE['branchName']
  //Ouput : 
  //  - list of {nom, prenom, uid, present}

  if (loadingE || loadingW || loadingU) return []

  if (!treeE) return []
  var dateTree = treeE[branchName]
  if (!dateTree || !treeU) return []

  //First, find the corresponding branch in dateTree
  var branch = dateTree[dateId]
  if (!branch) return []

  //Then populate res list
  var res = []
  let keysInscrits
  if (branch['inscrits']) {
    keysInscrits = Object.keys(branch['inscrits'])
  }
  else {
    keysInscrits = []
  }
  const keysUsers = Object.keys(treeW)
  for (const key of keysUsers) {
    if (key !== 'content') {
      var nom = treeU[key]['nom']
      var prenom = treeU[key]['prenom']
      var uid = key
      let present
      if (keysInscrits.includes(key)) {
        present = branch['inscrits'][key]['present']
      }
      else {
        present = 'Non renseigné'
      }
      res.push({ nom, prenom, uid, present })
    }
  }
  return res
}

function findLocationAndTime(treeE, loadingE, branchName, dateId) {
  //Inputs:
  //  - treeE : main firebase tree (namely "evenements")
  //  - loadingE : true if data is still loading
  //  - branchName : a branchName ("entrainements", "matchs", "pots", ...)
  //  - dateId : a date id
  //Ouput : 
  //  - {time, location}

  if (!dateId || !loadingE || !treeE) return ''

  var subTree = treeE[branchName]
  let location, time
  if (!subTree) {
    location = 'Lieu inconnu'
    time = 'Heure inconnue'
  }
  else if (!subTree[dateId]) {
    location = 'Lieu inconnu'
    time = 'Date inconnue'
  }
  else {
    location = subTree[dateId]['location']
    time = subTree[dateId]['readableTime']
  }
  const res = { location, time }
  return res
}


function GetDirectoryData(treeU, treeW) {
  //Inputs:
  //  - treeU : firebase tree containing all users
  //  - treeW : firebase tree of white listed users
  //Ouput : 
  //  - list of users with everything : {'nom', 'prenom', 'email', 'telephone' ...}
  if (!treeU || !treeW) return []

  var res = []
  //Looping on whiteListed users
  const keysUsers = Object.keys(treeW)
  for (const key of keysUsers) {
    if (treeU[key]) {
      res.push({ ...treeU[key], 'uid': key })
    }
  }
  return res.sort(mySort('a-z', false, '0'))
}

function GetAdminData(treeU, treeW) {
  //Inputs:
  //  - treeU : firebase tree containing all users
  //  - treeW : firebase tree of white listed users
  //Ouput : 
  //  - list of ALL users with everything : {'nom', 'prenom', 'email', 'telephone' ...}
  //  - plus one important info : is user in whiteList or not ?
  if (!treeU || !treeW) return []

  let temp
  var res = []
  //Looping on ALL users
  const keysUsers = Object.keys(treeU)
  for (const key of keysUsers) {
    temp = Object.assign({}, treeU[key]);
    if (!temp['nom']) temp['nom'] = '?'
    if (!temp['prenom']) temp['prenom'] = '?'
    if (treeW[key]) {
      if (treeW[key]['role'] !== 'admin') {
        res.push({ ...temp, 'uid': key, 'authorized': true })
      }
    }
    else {
      res.push({ ...temp, 'uid': key, 'authorized': false })
    }
  }
  return res.sort(sortAuth())
}

export default mySort
export { extractPresence, extractDates, mySort, findNextEvent, findLocationAndTime, GetDirectoryData, GetAdminData }