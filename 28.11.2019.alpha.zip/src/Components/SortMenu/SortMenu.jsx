import React, { useContext } from 'react'

import SortByAlphaIcon from '@material-ui/icons/SortByAlpha';
import IconButton from '@material-ui/core/IconButton';


import FirebaseContext from '../Firebase/FirebaseContext'

export default function SimpleMenu() {

  //Context de firebase : setTri(...) demande à (re)trier
  var { tri, setTri } = useContext(FirebaseContext);

  function handleClick(event) {
    if (tri === 'a-z') {
      setTri('presence')
    }
    else {
      setTri('a-z')
    }
  };

  return (
    <IconButton
      aria-controls="simple-menu"
      aria-haspopup="true"
      color="inherit"
      onClick={() => handleClick()}
    >
      <SortByAlphaIcon />
    </IconButton>
  );
}