import React, { useContext } from 'react'
import MyCard from '../MyCard/myCardc'

import FirebaseContext from '../Firebase/FirebaseContext'
import firebase from '../Firebase/firebase';

import { extractPresence, mySort } from '../UtilityScripts/TreeParsing'


export default function ListeSportifs(props) {

  const { trees, loadings, errors, user, tri } = useContext(FirebaseContext)
  const { currentDateId, trainingOrMatch } = props;


  //Get userId to highlight current user
  const userId = user['uid']

  //Liste des options de présence
  let options
  if (trainingOrMatch === 'entrainements') {
    options = ['Présent(e)', 'Provisoire', 'Absent(e)']
  }
  else {
    options = ['Oui', 'Non', 'Si besoin']
  }

  function updateListSportifs(dateId) {
    //Fonction qui met à jour la liste des sportifs
    if (loadings['loadingW'] || loadings['loadingU']) return

    //Pour que ça soit lisible
    const { treeE, treeU, treeW, treeP } = trees;
    const { loadingE, loadingU, loadingW, loadingP } = loadings;
    const { errorP } = errors;
    const branchName = trainingOrMatch

    var { sportifs } = extractPresence(treeE, loadingE, treeW, loadingW, treeU, loadingU, branchName, dateId)


    //Tri des sportifs
    //Show me first ?
    let meFirst
    if (!loadingP && !errorP) {
      meFirst = treeP['meFirst']
    }
    sportifs.sort(mySort(tri, meFirst, userId))

    return sportifs
  }

  function handleUpdateSportif(sportif) {
    //Fonction qui met à jour un sportif après modification éventuelle de sa présence
    var myRef = firebase.database().ref("evenements/").child(trainingOrMatch).child(currentDateId).child('inscrits').child(sportif['uid'])
    myRef.set({ present: sportif['present'] })
  }


  var sportifs = updateListSportifs(currentDateId)

  //Affichage de la liste si elle existe
  let listeSportifs
  if (sportifs.length === 0) {
    listeSportifs = ('Sélectionnez une date')
  }
  else {
    listeSportifs = (
      sportifs.map(sportif => <MyCard key={sportif['uid']}
        sportif={sportif}
        options={options}
        highlight={sportif['uid'] === userId}
        handleUpdateSportif={handleUpdateSportif} />)
    )
  }

  return (
    <div>
      {listeSportifs}
    </div>
  )
}