import React from 'react'

export default function RegisterForm() {
  return (<h1>Register Form</h1>)
}