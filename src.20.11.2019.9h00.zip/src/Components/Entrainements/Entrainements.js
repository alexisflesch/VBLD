import React, { Fragment, useContext } from 'react';
import MaterialUIPickers from '../DatePicker/datePicker';
import MyCard from '../MyCard/myCardc';
import CircularProgress from '@material-ui/core/CircularProgress';
import { makeStyles } from '@material-ui/core/styles';

import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';

import FirebaseContext from '../Firebase/FirebaseContext'
import { extractPresence2, extractDates, extractBranch, mySort, findNextEvent } from '../UtilityScripts/TreeParsing'


const useStyles = makeStyles(theme => ({
  titre: {
    padding: 0,
    marginTop: 0,
    marginBottom: 0,
  }
}));

export default function Entrainements(props) {
  //Entraînements ou matchs ?
  const { trainingOrMatch } = props;

  //Style
  const classes = useStyles();

  //Context de firebase
  const fire = useContext(FirebaseContext)

  //Liste des sportifs
  var listeSportifs = []
  //Lieu et heure de la rencontre
  var locationAndTime = ''

  //Date affichée au premier lancement --> à modifier
  // var date = new Date('2019-11-20')
  // var dateId = "-LtoyGU-OsDn2sv2wN3j"

  //Listes des dates des matchs (à donner au calendrier ensuite)
  var { datesAndMore, nextEvent } = extractDates(fire, trainingOrMatch)

  //Élément à afficher en cas de chargement
  var loadingDiv = (
    <Container maxWidth="xs">
      <Grid container justify="center">
        <CircularProgress size={40} />
      </Grid>
    </Container>
  )


  //Heure et lieu de la rencontre
  function findLocationAndTime(dateId) {
    if (!dateId) return ''
    if (fire['loadingTree']) return ''
    var subTree = extractBranch(fire, trainingOrMatch)
    let location, time
    if (!subTree) {
      location = 'Lieu inconnu'
      time = 'Heure inconnue'
    }
    else if (!subTree[dateId]) {
      location = 'Lieu inconnu'
      time = 'Date inconnue'
      console.log("tentative d'accès à une date non enregistrée")
    }
    else {
      location = subTree[dateId]['lieu']
      time = subTree[dateId]['readableTime']
    }
    locationAndTime = (
      <Container maxWidth="xs" className={classes.titre}>
        <Grid
          container
          direction="row"
          justify="center"
          alignItems="baseline"
          spacing={3}
        >
          <Grid item>
            <h2>{location}</h2>
          </Grid>
          <Grid item>
            <h3>{time}</h3>
          </Grid>
        </Grid>
      </Container >
    )
    return locationAndTime
  }


  //Liste des options de présence
  let options
  if (trainingOrMatch === 'entrainements') {
    options = ['Présent(e)', 'Provisoire', 'Absent(e)']
  }
  else {
    options = ['Oui', 'Non', 'Si besoin']
  }

  function updateListSportifs(dateid) {
    //Fonction qui met à jour la liste des sportifs
    if (fire['loadingTree']) return
    var sportifs = extractPresence2(fire, trainingOrMatch, dateid)
    //Tri des sportifs
    if (fire['tri'] === 'a-z') {
      sportifs.sort(mySort('a-z'))
    }
    else {
      sportifs.sort(mySort('presence'))
    }
    //Affichage de la liste si elle existe
    if (sportifs.length === 0) {
      // listeSportifs = loadingDiv
    }
    else {
      listeSportifs = (
        sportifs.map(sportif => <MyCard key={sportif['nom'] + sportif['prenom']}
          sportif={sportif}
          options={options}
          handleUpdateSportif={handleUpdateSportif} />)
      )
    }
  }

  function handleUpdateSportif(sportif) {
    //Fonction qui met à jour un sportif après modification éventuelle de sa présence
    var myRef = fire['firebase'].database().ref(trainingOrMatch).child(currentDateId).child('inscrits').child(sportif['uid'])
    myRef.set({ present: sportif['present'] })
  }


  function updateEverything(dateId) {
    findLocationAndTime(dateId)
    updateListSportifs(dateId)
  }

  //For some reason, on startup, dateId exists and currentDateId is not set
  //Quick and dirty fix
  // if (!currentDateId && dateId) {
  //   setCurrentDateId(dateId)
  // }
  //Date du prochain événement
  // const [date, dateId] = findNextEvent(fire, datesAndMore)
  const [date, dateId] = [nextEvent['date'], nextEvent['dateId']]

  //State passé au calendrier qui permettra de faire remonter l'info
  //si un changement de date a eu lieu
  const [currentDateId, setCurrentDateId] = React.useState(dateId)

  // React.useEffect(() => {
  //   var dateId = ''
  // }, [dateId, currentDateId]);


  // if (!currentDateId && dateId) {
  //   setCurrentDateId(dateId)
  // }

  console.log("dateId and currentDateId and datesAndMore and nextEvent below")
  console.log(dateId)
  console.log(currentDateId)
  console.log(datesAndMore)
  console.log(nextEvent)
  updateEverything(currentDateId)



  if (fire['loadingTree']) {
    return loadingDiv
  }
  else {
    return (
      <Fragment>
        <MaterialUIPickers
          currentDate={date}
          currentDateId={dateId}
          setCurrentDateId={setCurrentDateId}
          datesAndMore={datesAndMore}
        />
        {locationAndTime}
        {listeSportifs}
      </Fragment>
    )
  }

}
