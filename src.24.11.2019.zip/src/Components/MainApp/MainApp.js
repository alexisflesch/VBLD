import React from 'react';

import Matchs from '../Matchs/Matchs';
import News from '../Nouvelles/News';
import Pots from '../Pots/Pots'
import Entrainements from '../Entrainements/Entrainements';
import ResponsiveDrawer from '../Drawer/MyDrawer';
import Settings from '../Settings/Settings';
import Annuaire from '../Annuaire/Annuaire';
import Gymnases from '../Gymnases/Gymnases';

import firebase from '../Firebase/firebase';
import { FirebaseProvider } from '../Firebase/FirebaseContext';

import { useObjectVal } from 'react-firebase-hooks/database';
import SortMenu from '../SortMenu/SortMenu';


function MainApp() {

  //Firebase stuff : will be put in FirebaseContext later
  const [treeU, loadingTreeU, errorTreeU] = useObjectVal(firebase.database().ref('/users'));
  const [treeE, loadingTreeE, errorTreeE] = useObjectVal(firebase.database().ref('/evenements'));
  const [treeW, loadingTreeW, errorTreeW] = useObjectVal(firebase.database().ref('/whiteList'));

  const trees = { treeU, treeE, treeW };
  const loadings = { loadingTreeU, loadingTreeE, loadingTreeW };
  const errors = { errorTreeU, errorTreeE, errorTreeW };

  //Values to pass to the drawer
  const [mainDiv, setMainDiv] = React.useState(<Settings />);
  const [pageName, setPageName] = React.useState('Nouvelles');


  //Icône pour trier les sportifs ('a-z' ou 'presence')
  //On ajoutera dans le contexte principal un booléen qui passera à true quand il faudra trier
  //  - menu : chaîne de caractères affichée dans la bar principale (bouton de tri ou rien)
  //  - tri : le type de tri sur la liste des sportifs
  const [menu, setMenu] = React.useState('');
  const [tri, setTri] = React.useState('a-z')

  function handleDivChange(newDiv) {
    var futureDiv = "";
    var futureName = "";
    var futureMenu = "";
    if (newDiv === "disconnect") {
      firebase.auth().signOut();
    }
    if (newDiv === "news") {
      futureDiv = <News />
      futureName = "Nouvelles"
    }
    else if (newDiv === "matchs") {
      futureDiv = <Matchs />
      futureName = "Matchs"
      futureMenu = <SortMenu />
    }
    else if (newDiv === "entrainements") {
      futureDiv = <Entrainements />
      futureName = "Entraînements"
      futureMenu = <SortMenu />
    }
    else if (newDiv === "pots") {
      futureDiv = <Pots />
      futureName = "Pots"
    }
    else if (newDiv === "settings") {
      futureDiv = <Settings />
      futureName = "Paramètres"
    }
    else if (newDiv === "gymnases") {
      futureDiv = <Gymnases />
      futureName = "Gymnases"
    }
    else if (newDiv === "annuaire") {
      futureDiv = <Annuaire />
      futureName = "Annuaire"
    }
    setMainDiv(futureDiv);
    setPageName(futureName);
    setMenu(futureMenu)
  }



  return (
    <FirebaseProvider value={{ trees, loadings, errors, tri, setTri }}>
      <div>
        <ResponsiveDrawer
          div={mainDiv}
          pageName={pageName}
          handleChange={handleDivChange}
          menu={menu}
        />
      </div>
    </FirebaseProvider>
  );
}

export default MainApp;