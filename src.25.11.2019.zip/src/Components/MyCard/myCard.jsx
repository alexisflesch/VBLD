import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';

import Container from '@material-ui/core/Container';

import green from '@material-ui/core/colors/green';

const useStyles = makeStyles({
  card: {
    // paddingTop: -10,
    marginTop: 5,
    marginBottom: 5,
    height: 50,
  },
  cardcontent: {
    // paddingTop: -10,
    // marginTop: -10,
    // marginBottom: -10,
  },
  testcontent: {
    height: 50,
    margin: 0,
    padding: 0,
    marginTop: 25,
  },
  cardarea: {
    paddingTop: -10,
    marginTop: -10,
    marginBottom: -10,
  },
  media: {
    height: 20,
    width: 20,
  },
});

export default function MyCard() {
  const classes = useStyles();

  return (
    <Container maxWidth="xs">
      <Card className={classes.card} elevation={4}>
        <CardActionArea className={classes.cardarea}>
          <Grid
            container
            direction="row"
            justify="space-evenly"
            alignItems="center"
          >
            <Grid item xs={10}>
              <CardContent className={classes.cardcontent}>
                <Typography variant="h6">
                  Fourny Maxime
              </Typography>
                {/* <Typography variant="caption" color="textSecondary" component="p">
                  Présent
              </Typography> */}
              </CardContent>
            </Grid>
            <Grid item xs={2}>
              <Box className={classes.testcontent}
                bgcolor={green[500]}
              >
                &nbsp;
              </Box>
            </Grid>
          </Grid>
        </CardActionArea>
      </Card>
    </Container >
  );
}