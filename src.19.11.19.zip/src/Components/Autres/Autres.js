import React, { Fragment } from 'react';


export default function Autres() {
  return (
    <Fragment>
      Autres événements (pots, ... ?)
    </Fragment>
  )
}