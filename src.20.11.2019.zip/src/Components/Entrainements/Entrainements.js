import React, { Fragment, useContext } from 'react';
import MaterialUIPickers from '../DatePicker/datePicker';

import FirebaseContext from '../Firebase/FirebaseContext'
import { extractDates } from '../UtilityScripts/TreeParsing'

import ListeSportifs from '../ListeSportifs/ListeSportifs'
import LocationAndTime from '../LocationAndTime/LocationAndTime'
import LoadingDiv from '../LoadingDiv/LoadingDiv'

export default function Entrainements() {

  //Context de firebase
  const fire = useContext(FirebaseContext)

  //Listes des dates des matchs (à donner au calendrier ensuite)
  var { datesAndMore, nextEvent } = extractDates(fire, "entrainements")

  //Date du prochain événement
  var [date, dateId] = [nextEvent['date'], nextEvent['dateId']]

  //State passé au calendrier qui permettra de faire remonter l'info
  //si un changement de date a eu lieu
  const [currentDateId, setCurrentDateId] = React.useState(dateId)


  // Below is a fix needed if <Entrainements /> is the first thing
  // the app show.
  // currentDateId is not properly initialized because FirebaseContext
  // is initialized with a fake date while loading.
  // When the true initial value arrives, the react Hook waits for
  // the next render to update it
  // Quick and dirty fix
  // if (currentDateId === 'fake date id' && dateId !== 'fake date id') {
  //   setCurrentDateId(dateId)
  // }


  if (fire['loadingTree']) {
    return <LoadingDiv />
  }
  else {
    return (
      <Fragment>
        <MaterialUIPickers
          currentDate={date}
          currentDateId={currentDateId}
          setCurrentDateId={setCurrentDateId}
          datesAndMore={datesAndMore}
        />
        <LocationAndTime
          currentDate={date}
          currentDateId={currentDateId}
          trainingOrMatch="entrainements"
        />
        <ListeSportifs
          currentDateId={currentDateId}
          trainingOrMatch="entrainements"
        />
      </Fragment >
    )
  }

}
