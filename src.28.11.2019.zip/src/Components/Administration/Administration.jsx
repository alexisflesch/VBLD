import React, { Fragment, useContext } from 'react';
import { Typography } from '@material-ui/core';

import FirebaseContext from '../Firebase/FirebaseContext'
import { GetAdminData } from '../UtilityScripts/TreeParsing';
import LoadingDiv from '../LoadingDiv/LoadingDiv';
import DirectoryCard from '../DirectoryCard/DirectoryCard';
import firebase from '../Firebase/firebase';


export default function Administration() {

  const { trees, loadings, errors } = useContext(FirebaseContext)

  //Chargement en cours ou utilisateur non autorisé ou erreur Firebase
  if (loadings['loadingTreeU'] || loadings['loadingTreeW']) {
    return <LoadingDiv />
  }
  else if (errors['errorTreeU'] || errors['errorTreeW']) {
    return (
      <Fragment>
        <h3>Erreur</h3>
        <Typography>
          Une erreur est survenue : {errors['errorTreeU']}, {errors['errorTreeW']}
        </Typography>
      </Fragment>
    )
  }

  const data = GetAdminData(trees['treeU'], trees['treeW'])


  function handleClickAccept(sportif) {
    console.log("Authorizing user")
    console.log(sportif['uid'])
    var myRef = firebase.database().ref('/whiteList/' + sportif['uid'])
    myRef.set({ role: 'user' })
  }

  function handleClickBan(sportif) {
    console.log("Removing user from whiteList (provided that he is in it)")
    console.log(sportif['uid'])
    var myRef = firebase.database().ref('/whiteList/' + sportif['uid'])
    myRef.remove()
  }

  //Affichage de la liste si elle existe
  let annuaire
  if (!data) {
    annuaire = ('Problème')
  }
  else {
    annuaire = (
      data.map(sportif => <DirectoryCard key={sportif['uid']}
        sportif={sportif}
        authorized={sportif['authorized']}
        boutons="admin"
        handleClickAccept={() => handleClickAccept(sportif)}
        handleClickBan={() => handleClickBan(sportif)}
      />)
    )
  }


  return (
    <Fragment>
      {annuaire}
    </Fragment>
  )
}